Crop Recommendation System

Project Description

This project predicts the most suitable crop based on soil nutrients and weather conditions using Machine Learning.

Technologies Used

- Python 3.10
- Pandas
- NumPy
- Scikit-learn
- Flask
- Joblib

Installation

pip install -r requirements.txt

Run the Model

python model.py

Run the Flask Application

python app.py

Open your browser and visit:

http://127.0.0.1:5000

Dataset

- train-selected-columns.csv
- test.csv

Author

Ramanjana Devi