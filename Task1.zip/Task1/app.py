from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load the trained model
model = joblib.load("model.pkl")


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        pclass = int(request.form["Pclass"])
        sex = int(request.form["Sex"])
        age = float(request.form["Age"])
        sibsp = int(request.form["SibSp"])
        parch = int(request.form["Parch"])
        fare = float(request.form["Fare"])

        features = np.array([[pclass, sex, age, sibsp, parch, fare]])

        prediction = model.predict(features)

        if prediction[0] == 1:
            result = "Passenger Survived"
        else:
            result = "Passenger Did Not Survive"

        return render_template("index.html", prediction=result)

    except Exception as e:
        return render_template("index.html", prediction=f"Error: {e}")


if __name__ == "__main__":
    app.run(debug=True, port=5000)