import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load dataset
data = pd.read_csv("train-selected-columns.csv")

# Fill missing values
data["Age"].fillna(data["Age"].median(), inplace=True)

# Convert Sex column to numbers
data["Sex"] = data["Sex"].map({"male": 0, "female": 1})

# Drop unnecessary columns
data = data.drop(["PassengerId", "Name", "Ticket"], axis=1)

# Features and Target
X = data.drop("Survived", axis=1)
y = data["Survived"]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Train model
model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

model.fit(X_train, y_train)

# Prediction
y_pred = model.predict(X_test)

# Accuracy
print("Accuracy:", accuracy_score(y_test, y_pred))

# Classification Report
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Confusion Matrix
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Save model
joblib.dump(model, "model.pkl")

print("\nModel saved successfully as model.pkl")