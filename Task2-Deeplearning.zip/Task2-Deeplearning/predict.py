import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
import numpy as np
from tensorflow.keras.models import load_model
from PIL import Image
# Load trained model
model = load_model("model/mnist_cnn.h5")
# If you saved as .keras, use:
# model = load_model("model/mnist_cnn.keras")

def predict_digit(image_path):

    img = Image.open(image_path).convert("L")

    img = img.resize((28, 28))

    img = np.array(img)

    # Invert colors if background is white
    img = 255 - img

    img = img / 255.0

    img = img.reshape(1, 28, 28, 1)

    prediction = model.predict(img)

    digit = np.argmax(prediction)

    confidence = np.max(prediction) * 100

    return digit, confidence