import os
import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
import pandas as pd
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D
from tensorflow.keras.layers import Flatten, Dense, Dropout
from tensorflow.keras.utils import to_categorical

# -----------------------------
# Load Training Dataset
# -----------------------------
train_data = pd.read_csv("mnist_train.csv")

# First column = Label
y_train = train_data.iloc[:, 0].values

# Remaining columns = Pixels
X_train = train_data.iloc[:, 1:].values

# Normalize pixel values
X_train = X_train / 255.0

# Reshape to 28x28x1
X_train = X_train.reshape(-1, 28, 28, 1)

# One-hot encoding
y_train = to_categorical(y_train, 10)

# -----------------------------
# Load Test Dataset
# -----------------------------
test_data = pd.read_csv("mnist_test.csv")

y_test = test_data.iloc[:, 0].values
X_test = test_data.iloc[:, 1:].values

X_test = X_test / 255.0
X_test = X_test.reshape(-1, 28, 28, 1)

y_test = to_categorical(y_test, 10)

# -----------------------------
# Build CNN Model
# -----------------------------
model = Sequential()

model.add(Conv2D(
    filters=32,
    kernel_size=(3, 3),
    activation='relu',
    input_shape=(28, 28, 1)
))

model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Conv2D(
    filters=64,
    kernel_size=(3, 3),
    activation='relu'
))

model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Flatten())

model.add(Dense(128, activation='relu'))

model.add(Dropout(0.3))

model.add(Dense(10, activation='softmax'))

# -----------------------------
# Compile Model
# -----------------------------
model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

print("\nTraining Started...\n")

# -----------------------------
# Train Model
# -----------------------------
history = model.fit(
    X_train,
    y_train,
    epochs=5,
    batch_size=64,
    validation_split=0.2,
    verbose=1
)

# -----------------------------
# Evaluate Model
# -----------------------------
loss, accuracy = model.evaluate(
    X_test,
    y_test,
    verbose=0
)

print("\n==============================")
print("Test Accuracy : {:.2f}%".format(accuracy * 100))
print("==============================")

# -----------------------------
# Save Model
# -----------------------------
os.makedirs("model", exist_ok=True)

model.save("model/mnist_cnn.h5")

print("\nModel Saved Successfully!")
print("Location : model/mnist_cnn.h5")