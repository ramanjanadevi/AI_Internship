import os

print("Step 1")

from flask import Flask, render_template, request

print("Step 2")

from predict import predict_digit

print("Step 3")

from explain import generate_explanation

print("Step 4")

app = Flask(__name__)

print("Step 5")

# Upload folder
UPLOAD_FOLDER = "static/upload"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():

    if "image" not in request.files:
        return "No image uploaded."

    file = request.files["image"]

    if file.filename == "":
        return "Please select an image."

    filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)

    file.save(filepath)

    digit, confidence = predict_digit(filepath)
    explanation = generate_explanation(filepath)

    return render_template(
        "result.html",
        digit=digit,
        confidence=round(confidence, 2),
        image=file.filename,
        explanation=explanation
    )


if __name__ == "__main__":
    print("Starting Flask...")
    app.run(debug=True,port=5003)