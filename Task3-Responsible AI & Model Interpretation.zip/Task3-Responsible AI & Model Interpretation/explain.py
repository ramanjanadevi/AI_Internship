import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image


def generate_explanation(image_path):
    """
    Generate a simple heatmap explanation
    """

    # Create explanation folder if it doesn't exist
    os.makedirs("static/explanation", exist_ok=True)

    # Load image
    img = Image.open(image_path).convert("L")
    img = img.resize((28, 28))

    img = np.array(img)

    # Create heatmap
    heatmap = cv2.applyColorMap(img.astype(np.uint8), cv2.COLORMAP_JET)

    # Save explanation image
    save_path = "static/explanation/explanation.png"

    plt.figure(figsize=(4,4))
    plt.imshow(cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB))
    plt.axis("off")
    plt.title("Model Explanation")
    plt.savefig(save_path, bbox_inches="tight")
    plt.close()

    return "explanation/explanation.png"