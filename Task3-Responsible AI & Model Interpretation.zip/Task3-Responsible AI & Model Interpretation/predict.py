import numpy as np
from PIL import Image

print("Importing TensorFlow...")
from tensorflow.keras.models import load_model

print("Loading model...")
model = load_model("model/mnist_cnn.h5")
print("Model loaded successfully.")
def preprocess_image(image_path):
    """
    Preprocess uploaded image for MNIST CNN model
    """

    # Open image and convert to grayscale
    img = Image.open(image_path).convert("L")

    # Resize to 28x28
    img = img.resize((28, 28))

    # Convert to numpy array
    img = np.array(img)

    # Invert colors if needed
    # MNIST uses white digit on black background
    img = 255 - img

    # Normalize pixel values
    img = img / 255.0

    # Reshape for CNN
    img = img.reshape(1, 28, 28, 1)

    return img


def predict_digit(image_path):
    """
    Predict handwritten digit
    """

    img = preprocess_image(image_path)

    prediction = model.predict(img, verbose=0)

    predicted_digit = int(np.argmax(prediction))

    confidence = float(np.max(prediction) * 100)

    return predicted_digit, confidence