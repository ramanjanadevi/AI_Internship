import os
import pandas as pd
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.utils import to_categorical

# Create model folder
os.makedirs("model", exist_ok=True)

# Load dataset
train = pd.read_csv("dataset/mnist_train.csv")

# Features and labels
X = train.iloc[:, 1:].values
y = train.iloc[:, 0].values

# Normalize
X = X / 255.0

# Reshape
X = X.reshape(-1, 28, 28, 1)

# One-hot encode labels
y = to_categorical(y, 10)

# CNN Model
model = Sequential([
    Conv2D(32, (3,3), activation="relu", input_shape=(28,28,1)),
    MaxPooling2D((2,2)),
    Conv2D(64, (3,3), activation="relu"),
    MaxPooling2D((2,2)),
    Flatten(),
    Dense(128, activation="relu"),
    Dense(10, activation="softmax")
])

# Compile
model.compile(
    optimizer="adam",
    loss="categorical_crossentropy",
    metrics=["accuracy"]
)

# Train
model.fit(X, y, epochs=5, batch_size=32)

# Save model
model.save("model/mnist_cnn.h5")

print("Model saved successfully.")